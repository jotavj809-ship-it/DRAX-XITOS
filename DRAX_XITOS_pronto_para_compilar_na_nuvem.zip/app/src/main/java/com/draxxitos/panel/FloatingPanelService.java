package com.draxxitos.panel;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingPanelService extends Service {
    private WindowManager wm;
    private WindowManager.LayoutParams panelParams, bubbleParams;
    private View panel, bubble;
    private int fov = 90;
    private int panelWidthDp = 280;
    private boolean expanded = true;
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }

    @Override public void onCreate() {
        super.onCreate();
        startAsForeground();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        showPanel();
    }

    private void startAsForeground() {
        String channel = "drax_panel";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(channel, "DRAX XITOS", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
            Notification n = new Notification.Builder(this, channel)
                .setContentTitle("DRAX XITOS ativo")
                .setContentText("O ícone flutuante está disponível.")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build();
            startForeground(7, n);
        }
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), Color.rgb(110, 85, 255));
        return d;
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(12);
        return b;
    }

    private WindowManager.LayoutParams params(int width, int height) {
        int type = Build.VERSION.SDK_INT >= 26 ?
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
            WindowManager.LayoutParams.TYPE_PHONE;
        return new WindowManager.LayoutParams(width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
    }

    private void showPanel() {
        if (panel != null) { try { wm.removeView(panel); } catch(Exception ignored) {} }
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(8), dp(10), dp(8));
        root.setBackground(bg(Color.rgb(20, 20, 32), 16));

        TextView header = text("DRAX XITOS   •   —", 17, Color.WHITE);
        header.setTypeface(null, Typeface.BOLD);
        header.setBackground(bg(Color.rgb(55, 40, 110), 10));
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(44)));
        header.setOnClickListener(v -> minimize());

        TextView value = text("FOV (demonstração): " + fov, 14, Color.WHITE);
        root.addView(value, new LinearLayout.LayoutParams(-1, dp(38)));

        LinearLayout fovRow = new LinearLayout(this);
        Button minus = button("FOV −");
        Button plus = button("FOV +");
        fovRow.addView(minus, new LinearLayout.LayoutParams(0, dp(48), 1));
        fovRow.addView(plus, new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(fovRow);
        minus.setOnClickListener(v -> { fov = Math.max(30, fov - 5); value.setText("FOV (demonstração): " + fov); });
        plus.setOnClickListener(v -> { fov = Math.min(150, fov + 5); value.setText("FOV (demonstração): " + fov); });

        TextView widthLabel = text("Largura do painel: " + panelWidthDp + " dp", 13, Color.WHITE);
        root.addView(widthLabel, new LinearLayout.LayoutParams(-1, dp(36)));
        LinearLayout widthRow = new LinearLayout(this);
        Button narrower = button("− Largura");
        Button wider = button("+ Largura");
        widthRow.addView(narrower, new LinearLayout.LayoutParams(0, dp(46), 1));
        widthRow.addView(wider, new LinearLayout.LayoutParams(0, dp(46), 1));
        root.addView(widthRow);
        narrower.setOnClickListener(v -> { panelWidthDp = Math.max(220, panelWidthDp - 20); widthLabel.setText("Largura do painel: " + panelWidthDp + " dp"); resizePanel(); });
        wider.setOnClickListener(v -> { panelWidthDp = Math.min(360, panelWidthDp + 20); widthLabel.setText("Largura do painel: " + panelWidthDp + " dp"); resizePanel(); });

        Button launch = button("ABRIR FREE FIRE");
        root.addView(launch, new LinearLayout.LayoutParams(-1, dp(48)));
        launch.setOnClickListener(v -> openFreeFire());

        Button hide = button("MINIMIZAR PARA ÍCONE");
        root.addView(hide, new LinearLayout.LayoutParams(-1, dp(46)));
        hide.setOnClickListener(v -> minimize());

        panel = root;
        panelParams = params(dp(panelWidthDp), -2);
        panelParams.gravity = Gravity.TOP | Gravity.RIGHT;
        panelParams.x = dp(10); panelParams.y = dp(90);
        try { wm.addView(panel, panelParams); } catch (Exception e) {
            Toast.makeText(this, "Não foi possível mostrar o painel.", Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private void resizePanel() {
        if (panel != null && panelParams != null) {
            panelParams.width = dp(panelWidthDp);
            try { wm.updateViewLayout(panel, panelParams); } catch(Exception ignored) {}
        }
    }

    private void minimize() {
        if (panel != null) { try { wm.removeView(panel); } catch(Exception ignored) {} panel = null; }
        if (bubble != null) return;
        TextView icon = text("DX", 18, Color.WHITE);
        icon.setTypeface(null, Typeface.BOLD);
        icon.setBackground(bg(Color.rgb(85, 55, 210), 28));
        bubble = icon;
        bubbleParams = params(dp(58), dp(58));
        bubbleParams.gravity = Gravity.TOP | Gravity.LEFT;
        bubbleParams.x = dp(12); bubbleParams.y = dp(180);
        icon.setOnClickListener(v -> restore());
        icon.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy, ox, oy;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) { sx=(int)e.getRawX(); sy=(int)e.getRawY(); ox=bubbleParams.x; oy=bubbleParams.y; return false; }
                if (e.getAction() == MotionEvent.ACTION_MOVE) { bubbleParams.x=ox+(int)e.getRawX()-sx; bubbleParams.y=oy+(int)e.getRawY()-sy; try { wm.updateViewLayout(bubble,bubbleParams); } catch(Exception ignored){} return true; }
                return false;
            }
        });
        try { wm.addView(bubble, bubbleParams); } catch(Exception ignored) {}
    }

    private void restore() {
        if (bubble != null) { try { wm.removeView(bubble); } catch(Exception ignored) {} bubble = null; }
        showPanel();
    }

    private void openFreeFire() {
        Intent i = getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
        if (i == null) i = getPackageManager().getLaunchIntentForPackage("com.dts.freefiremax");
        if (i == null) {
            Toast.makeText(this, "Free Fire não encontrado. Instale o jogo oficial.", Toast.LENGTH_LONG).show();
            return;
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() {
        if (panel != null) try { wm.removeView(panel); } catch(Exception ignored) {}
        if (bubble != null) try { wm.removeView(bubble); } catch(Exception ignored) {}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
